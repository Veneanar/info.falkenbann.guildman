<?php
namespace wcf\system\event\listener;
use wcf\data\wow\character\WowCharacterList;

class CharacterRouteEventListener implements IParameterizedEventListener {
	public function execute($eventObj, $className, $eventName, array &$parameters) {

	}
}
